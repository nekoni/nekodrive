extern void foo (void);
extern void bar (void);

void
bar (void)
{
  foo ();
}
