#include "tst-stackguard1.c"
