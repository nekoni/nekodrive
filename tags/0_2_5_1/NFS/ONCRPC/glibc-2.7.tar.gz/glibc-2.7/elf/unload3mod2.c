int dummy2;
