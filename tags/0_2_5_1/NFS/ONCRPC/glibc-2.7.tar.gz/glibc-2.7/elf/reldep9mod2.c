void baz (void)
{
}
